# Editing guide

| I want to change...            | Edit this file                          |
|--------------------------------|-----------------------------------------|
| App name / theme               | src/config/site.config.js (SITE)        |
| API address                    | .env  (VITE_API_BASE_URL)               |
| Which role sees which page     | src/config/site.config.js (ROLE_TABS) + src/assets/js/roleAccess.js |
| Calling the API                | import { apiGet, apiPost } from src/lib/http.js |
| Reading the login token        | import { getToken } from src/lib/auth.js |
| Showing admin-written HTML     | <SafeHtml html={...} /> — never dangerouslySetInnerHTML |

## Security rules baked in
1. Token: sessionStorage by default; localStorage only if "Remember me".
2. All DB-authored HTML goes through an allow-list sanitizer (no scripts, handlers, styles, javascript: links).
3. No hardcoded server URLs; backup calls send the auth token.
4. CSP + referrer policy in index.html. .env is git-ignored.
5. UI role checks only hide buttons. The backend MUST enforce roles on every endpoint.
