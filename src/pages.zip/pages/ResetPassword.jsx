import React, { useMemo, useState } from "react";
import Swal from "sweetalert2";

import {
  showErrorAlert,
  showLoadingPopup,
  showSuccessAlert,
} from "../assets/js/swalHelpers";

import { useAppSettings } from "../assets/js/useAppSettings";

import { API_BASE_URL } from "../assets/js/appConfig";

import {
  PageBackground,
  PageCard,
  SystemLogo,
  Footer,
  SettingsLoading,
} from "./inc/PagesComponents";

import Maintenance from "./Maintenance";

// ==========================================================
// PASSWORD INPUT
// ==========================================================

function PasswordInput({
  id,
  label,
  value,
  onChange,
  placeholder,
  showPassword,
  onToggle,
  disabled,
}) {
  return (
    <div>
      <label
        htmlFor={id}
        className="out-label"
      >
        {label}
      </label>

      <div className="group relative">
        <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 transition-colors group-focus-within:text-emerald-600">
          <i className="bi bi-lock text-base" />
        </span>

        <input
          id={id}
          name={id}
          type={showPassword ? "text" : "password"}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          autoComplete="new-password"
          disabled={disabled}
          required
          className="out-input"
        />

        <button
          type="button"
          onClick={onToggle}
          disabled={disabled}
          aria-label={
            showPassword
              ? "Hide password"
              : "Show password"
          }
          className="absolute inset-y-0 right-0 flex items-center pr-4 text-slate-400 transition-colors hover:text-slate-600 disabled:cursor-not-allowed"
        >
          <i
            className={
              showPassword
                ? "bi bi-eye-slash"
                : "bi bi-eye"
            }
          />
        </button>
      </div>
    </div>
  );
}

// ==========================================================
// MAIN COMPONENT
// ==========================================================

export default function ResetPassword() {
  // ========================================================
  // SETTINGS
  // ========================================================

  const {
    settingsLoading,

    siteName,
    siteCopyright,
    logoUrl,
    backgroundUrl,
    backgroundStyle,

    maintenanceDateFormat,
    maintenanceTimeFormat,

    maintenanceTitle,
    maintenanceSubject,
    maintenanceStartTime,
    maintenanceEndTime,
    maintenanceMessage,

    isUnderMaintenance,
  } = useAppSettings();

  const systemName =
    siteName || "System Portal";

  // ========================================================
  // RESET PARAMETERS
  // ========================================================

  const queryParams = useMemo(
    () =>
      new URLSearchParams(
        window.location.search,
      ),
    [],
  );

  const token =
    queryParams.get("token") || "";

  const email =
    queryParams.get("email") || "";

  // ========================================================
  // STATE
  // ========================================================

  const [password, setPassword] =
    useState("");

  const [confirmPassword, setConfirmPassword] =
    useState("");

  const [showPassword, setShowPassword] =
    useState(false);

  const [
    showConfirmPassword,
    setShowConfirmPassword,
  ] = useState(false);

  const [isLoading, setIsLoading] =
    useState(false);

  const [isRefreshing, setIsRefreshing] =
    useState(false);

  // ========================================================
  // API ERROR
  // ========================================================

  const getApiErrorMessage = (
    data,
    fallback,
  ) => {
    let message =
      data?.message ||
      data?.detail ||
      fallback;

    if (
      data?.errors &&
      typeof data.errors === "object"
    ) {
      const firstError = Object.values(
        data.errors,
      )
        .flat()
        .find(Boolean);

      if (firstError) {
        message = firstError;
      }
    }

    return message;
  };

  // ========================================================
  // REFRESH
  // ========================================================

  const handleRefresh = () => {
    if (isRefreshing) return;

    setIsRefreshing(true);

    window.setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  // ========================================================
  // SUBMIT
  // ========================================================

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (settingsLoading) {
      return;
    }

    // ------------------------------------------------------
    // MAINTENANCE
    // ------------------------------------------------------

    if (isUnderMaintenance) {
      showErrorAlert(
        "The system is currently under maintenance. Please try again later.",
      );

      return;
    }

    // ------------------------------------------------------
    // LINK VALIDATION
    // ------------------------------------------------------

    if (!token || !email) {
      showErrorAlert(
        "This password reset link is invalid or incomplete.",
      );

      return;
    }

    // ------------------------------------------------------
    // PASSWORD VALIDATION
    // ------------------------------------------------------

    if (!password) {
      showErrorAlert(
        "Please enter your new password.",
      );

      return;
    }

    if (password.length < 8) {
      showErrorAlert(
        "Password must be at least 8 characters.",
      );

      return;
    }

    if (!confirmPassword) {
      showErrorAlert(
        "Please confirm your new password.",
      );

      return;
    }

    if (password !== confirmPassword) {
      showErrorAlert(
        "Passwords do not match.",
      );

      return;
    }

    setIsLoading(true);

    showLoadingPopup(
      "Resetting your password...",
    );

    try {
      const response = await fetch(
        `${API_BASE_URL}/reset-password`,
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",

            Accept: "application/json",
          },

          body: JSON.stringify({
            email,
            token,
            password,
            password_confirmation:
              confirmPassword,
          }),
        },
      );

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      // ----------------------------------------------------
      // API ERROR
      // ----------------------------------------------------

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(
            data,
            "Unable to reset your password.",
          ),
        );
      }

      // ----------------------------------------------------
      // SUCCESS
      // ----------------------------------------------------

      Swal.close();

      showSuccessAlert(
        data?.message ||
          "Password reset successfully.",
        1800,
      );

      setPassword("");
      setConfirmPassword("");

      setTimeout(() => {
        window.location.assign("/");
      }, 1800);
    } catch (error) {
      console.error(
        "Reset password error:",
        error,
      );

      Swal.close();

      showErrorAlert(
        error?.message ||
          "An unexpected network error occurred.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================================
  // SETTINGS LOADING
  // ========================================================

  if (settingsLoading) {
    return <SettingsLoading />;
  }

  // ========================================================
  // MAINTENANCE
  // ========================================================

  if (isUnderMaintenance) {
    return (
      <Maintenance
        siteName={siteName}
        siteCopyright={siteCopyright}
        logoUrl={logoUrl}
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        maintenanceTitle={maintenanceTitle}
        maintenanceSubject={maintenanceSubject}
        maintenanceStartTime={
          maintenanceStartTime
        }
        maintenanceEndTime={
          maintenanceEndTime
        }
        maintenanceMessage={
          maintenanceMessage
        }
        maintenanceDateFormat={
          maintenanceDateFormat
        }
        maintenanceTimeFormat={
          maintenanceTimeFormat
        }
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />
    );
  }

  // ========================================================
  // PAGE
  // ========================================================

  return (
    <div
      className="out-page-container"
      style={backgroundStyle}
    >
      <PageBackground
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
      />

      <PageCard>
        {/* ==================================================
            HEADER
        ================================================== */}

        <div className="text-center">
          <SystemLogo
            logoUrl={logoUrl}
            siteName={systemName}
          />

          <div className="mt-2">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-emerald-700">
              <i className="bi bi-shield-check" />
              Account Security
            </div>

            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-slate-900">
              Reset Password
            </h1>

            <p className="mx-auto mt-2 max-w-sm text-sm leading-5 text-slate-500">
              Create a new password for your account.
            </p>
          </div>
        </div>

        {/* ==================================================
            ACCOUNT EMAIL
        ================================================== */}

        <div className="mt-5 rounded-2xl border border-emerald-100 bg-emerald-50/60 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600">
              <i className="bi bi-envelope" />
            </div>

            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                Account
              </p>

              <p className="truncate text-sm font-semibold text-slate-700">
                {email || "Unknown email"}
              </p>
            </div>
          </div>
        </div>

        {/* ==================================================
            FORM
        ================================================== */}

        <form
          onSubmit={handleSubmit}
          className="mt-5 space-y-4"
        >
          <PasswordInput
            id="password"
            label="New Password"
            value={password}
            onChange={(e) =>
              setPassword(e.target.value)
            }
            placeholder="Minimum 8 characters"
            showPassword={showPassword}
            onToggle={() =>
              setShowPassword(
                (prev) => !prev,
              )
            }
            disabled={isLoading}
          />

          <p className="-mt-2 flex items-center gap-1 text-[11px] text-slate-400">
            <i className="bi bi-info-circle" />
            Password must contain at least 8 characters.
          </p>

          <PasswordInput
            id="confirmPassword"
            label="Confirm Password"
            value={confirmPassword}
            onChange={(e) =>
              setConfirmPassword(
                e.target.value,
              )
            }
            placeholder="Repeat your password"
            showPassword={
              showConfirmPassword
            }
            onToggle={() =>
              setShowConfirmPassword(
                (prev) => !prev,
              )
            }
            disabled={isLoading}
          />

          {confirmPassword &&
            password === confirmPassword && (
              <p className="-mt-2 flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                <i className="bi bi-check-circle" />
                Passwords match
              </p>
            )}

          {/* =================================================
              ACTION BUTTONS
          ================================================= */}

          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              disabled={isLoading}
              onClick={() =>
                window.location.assign("/")
              }
              className="out-secondary-btn"
            >
              <i className="bi bi-arrow-left" />
              Back to Sign In
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="out-submit-btn"
            >
              {isLoading ? (
                <>
                  <i className="bi bi-arrow-repeat animate-spin" />
                  Resetting...
                </>
              ) : (
                <>
                  <i className="bi bi-shield-check" />
                  Reset Password
                </>
              )}
            </button>
          </div>
        </form>

        {/* ==================================================
            FOOTER
        ================================================== */}

        <Footer
          siteCopyright={siteCopyright}
          siteName={systemName}
        />
      </PageCard>
    </div>
  );
}