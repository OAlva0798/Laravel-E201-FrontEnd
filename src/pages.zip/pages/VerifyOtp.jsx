import React, { useEffect, useMemo, useState, useRef, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Swal from "sweetalert2";

import {
  showErrorAlert,
  showLoadingPopup,
  showSuccessAlert,
} from "../assets/js/swalHelpers";

import { useAppSettings } from "../assets/js/useAppSettings";
import { API_BASE_URL, isValidEmail } from "../assets/js/appConfig";

import {
  PageBackground,
  PageCard,
  SystemLogo,
  Footer,
  SettingsLoading,
} from "./inc/PagesComponents";

import Maintenance from "./Maintenance";

// ==========================================================
// SEGMENTED OTP INPUT
// ==========================================================

function OtpInput({ otp, setOtp, disabled, onComplete, autoFocus = true }) {
  const inputRef = useRef(null);
  const LENGTH = 6;

  const handleChange = (e) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, LENGTH);
    setOtp(value);

    if (value.length === LENGTH && onComplete) {
      onComplete(value);
    }
  };

  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between">
        <label htmlFor="otp-input" className="out-label">
          Verification Code
        </label>
        <span className="text-[11px] font-medium text-slate-400">
          6-digit code
        </span>
      </div>

      {/* Input Box Container */}
      <div
        onClick={handleContainerClick}
        className="relative my-3 flex cursor-pointer justify-center items-center gap-2 sm:gap-3"
      >
        {/* Hidden functional input overlays the visual boxes for native autofill/keyboard support */}
        <input
          id="otp-input"
          ref={inputRef}
          type="text"
          inputMode="numeric"
          autoComplete="one-time-code"
          pattern="[0-9]*"
          maxLength={LENGTH}
          value={otp}
          onChange={handleChange}
          disabled={disabled}
          autoFocus={autoFocus}
          aria-label="Enter 6-digit verification code"
          className="absolute inset-0 z-10 h-full w-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
        />

        {/* Visual Digits */}
        {Array.from({ length: LENGTH }).map((_, index) => {
          const digit = otp[index] || "";
          const isCurrent = index === otp.length && otp.length < LENGTH;
          const isFilled = Boolean(digit);

          return (
            <div
              key={index}
              className={`relative flex h-13 w-11 sm:h-14 sm:w-12 items-center justify-center rounded-xl border-2 text-xl font-black transition-all duration-200 select-none ${
                isFilled
                  ? "border-emerald-500 bg-emerald-50/40 text-emerald-950 shadow-sm"
                  : isCurrent
                  ? "border-emerald-500 bg-white ring-4 ring-emerald-500/15"
                  : "border-slate-200 bg-slate-50/50 text-slate-800 hover:border-slate-300"
              } ${disabled ? "bg-slate-100 opacity-60 cursor-not-allowed" : ""}`}
            >
              {digit}

              {/* Blinking Cursor Indicator */}
              {!digit && isCurrent && !disabled && (
                <span className="h-5 w-0.5 animate-pulse rounded-full bg-emerald-600" />
              )}
            </div>
          );
        })}
      </div>

      <p className="text-center text-xs text-slate-400">
        Enter or paste the 6-digit code sent to your email.
      </p>
    </div>
  );
}

// ==========================================================
// MAIN VERIFY OTP COMPONENT
// ==========================================================

function VerifyOtp({ onLoginSuccess }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // ========================================================
  // APP SETTINGS
  // ========================================================

  const {
    settingsLoading,
    siteName,
    siteCopyright,
    logoUrl,
    backgroundUrl,
    backgroundStyle,
    maintenanceDateFormat,
    maintenanceTimeFormat,
    maintenanceTitle,
    maintenanceSubject,
    maintenanceStartTime,
    maintenanceEndTime,
    maintenanceMessage,
    isUnderMaintenance,
  } = useAppSettings();

  const systemName = siteName || "System Portal";

  // ========================================================
  // QUERY PARAMETERS
  // ========================================================

  const email = useMemo(
    () => String(searchParams.get("email") || "").trim().toLowerCase(),
    [searchParams],
  );

  const rememberMe = searchParams.get("remember_me") === "1";

  // ========================================================
  // STATE
  // ========================================================

  const [otp, setOtp] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [remainingAttempts, setRemainingAttempts] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // ========================================================
  // VALIDATE INITIAL REQUEST
  // ========================================================

  useEffect(() => {
    if (!email || !isValidEmail(email)) {
      showErrorAlert("Invalid OTP verification request.");
      navigate("/", { replace: true });
    }
  }, [email, navigate]);

  // ========================================================
  // RESEND TIMER COUNTDOWN
  // ========================================================

  useEffect(() => {
    if (countdown <= 0) return undefined;

    const timer = window.setInterval(() => {
      setCountdown((current) => Math.max(0, current - 1));
    }, 1000);

    return () => window.clearInterval(timer);
  }, [countdown]);

  // ========================================================
  // ERROR PARSER
  // ========================================================

  const getApiErrorMessage = (data, fallback) => {
    let message = data?.message || data?.detail || fallback;

    if (data?.errors && typeof data.errors === "object") {
      const firstError = Object.values(data.errors).flat().find(Boolean);
      if (firstError) message = firstError;
    }

    return message;
  };

  // ========================================================
  // REFRESH
  // ========================================================

  const handleRefresh = () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    window.setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  // ========================================================
  // VERIFY OTP API
  // ========================================================

  const executeVerification = useCallback(
    async (codeToVerify) => {
      const code = codeToVerify || otp;

      if (settingsLoading || isUnderMaintenance || isLoading) return;

      if (!email || !isValidEmail(email)) {
        showErrorAlert("Invalid OTP verification request.");
        return;
      }

      if (!/^\d{6}$/.test(code)) {
        showErrorAlert("Please enter a valid 6-digit verification code.");
        return;
      }

      setIsLoading(true);
      showLoadingPopup("Verifying code...");

      try {
        const response = await fetch(`${API_BASE_URL}/verify-otp`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({
            uacc_email: email,
            otp: code,
            remember_me: rememberMe,
          }),
        });

        let data = {};
        try {
          data = await response.json();
        } catch {
          data = {};
        }

        if (!response.ok) {
          if (Number.isInteger(data?.remaining_attempts)) {
            setRemainingAttempts(data.remaining_attempts);
          }

          throw new Error(
            getApiErrorMessage(data, "Unable to verify the verification code."),
          );
        }

        if (!data?.access_token || !data?.user) {
          throw new Error(
            "OTP was verified, but the authentication response was incomplete.",
          );
        }

        Swal.close();
        showSuccessAlert("Verification successful! Signing you in...", 800);

        window.setTimeout(() => {
          onLoginSuccess?.(data, rememberMe);
          navigate("/", { replace: true });
        }, 800);
      } catch (error) {
        console.error("OTP verification error:", error);
        Swal.close();
        showErrorAlert(error?.message || "An unexpected network error occurred.");
      } finally {
        setIsLoading(false);
      }
    },
    [
      otp,
      settingsLoading,
      isUnderMaintenance,
      isLoading,
      email,
      rememberMe,
      onLoginSuccess,
      navigate,
    ],
  );

  const handleVerifyFormSubmit = (event) => {
    event.preventDefault();
    executeVerification();
  };

  // Auto-submit when all 6 digits are entered
  const handleOtpComplete = (completedOtp) => {
    executeVerification(completedOtp);
  };

  // ========================================================
  // RESEND OTP API
  // ========================================================

  const handleResend = async () => {
    if (
      settingsLoading ||
      isUnderMaintenance ||
      resending ||
      countdown > 0 ||
      !email
    ) {
      return;
    }

    setResending(true);
    showLoadingPopup("Sending a new verification code...");

    try {
      const response = await fetch(`${API_BASE_URL}/resend-otp`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({ uacc_email: email }),
      });

      let data = {};
      try {
        data = await response.json();
      } catch {
        data = {};
      }

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(data, "Unable to send a new verification code."),
        );
      }

      setOtp("");
      setRemainingAttempts(null);
      setCountdown(60);

      Swal.close();
      showSuccessAlert(
        data?.message || "A new verification code has been sent.",
        1400,
      );
    } catch (error) {
      console.error("OTP resend error:", error);
      Swal.close();
      showErrorAlert(error?.message || "An unexpected network error occurred.");
    } finally {
      setResending(false);
    }
  };

  const handleBackToLogin = () => {
    window.location.assign("/");
  };

  // ========================================================
  // RENDER CONDITIONAL STATES
  // ========================================================

  if (settingsLoading) {
    return <SettingsLoading />;
  }

  if (isUnderMaintenance) {
    return (
      <Maintenance
        siteName={siteName}
        siteCopyright={siteCopyright}
        logoUrl={logoUrl}
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        maintenanceTitle={maintenanceTitle}
        maintenanceSubject={maintenanceSubject}
        maintenanceStartTime={maintenanceStartTime}
        maintenanceEndTime={maintenanceEndTime}
        maintenanceMessage={maintenanceMessage}
        maintenanceDateFormat={maintenanceDateFormat}
        maintenanceTimeFormat={maintenanceTimeFormat}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />
    );
  }

  if (!email || !isValidEmail(email)) {
    return null;
  }

  // ========================================================
  // MAIN UI
  // ========================================================

  return (
    <div className="out-page-container" style={backgroundStyle}>
      <PageBackground
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
      />

      <PageCard>
        {/* Header */}
        <div className="text-center">
          <SystemLogo logoUrl={logoUrl} siteName={systemName} />

          <div className="mt-3">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-emerald-700">
              <i className="bi bi-shield-check text-xs" />
              Two-Factor Authentication
            </span>

            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-slate-900">
              Verify Your Sign In
            </h1>

            <p className="mx-auto mt-1.5 max-w-sm text-sm text-slate-500">
              Check your inbox for the 6-digit passcode we just sent you.
            </p>
          </div>
        </div>

        {/* Email Callout Box */}
        <div className="mt-5 rounded-2xl border border-emerald-100 bg-emerald-50/50 p-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700">
                <i className="bi bi-envelope-check text-lg" />
              </div>

              <div className="min-w-0">
                <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                  Code sent to
                </p>
                <p className="truncate text-xs font-bold text-slate-800" title={email}>
                  {email}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleBackToLogin}
              className="shrink-0 rounded-lg px-2.5 py-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-100/60 transition-colors"
            >
              Change
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleVerifyFormSubmit} className="mt-5 space-y-4">
          <OtpInput
            otp={otp}
            setOtp={(val) => {
              setOtp(val);
              setRemainingAttempts(null);
            }}
            disabled={isLoading || resending}
            onComplete={handleOtpComplete}
          />

          {/* Remaining Attempts Callout */}
          {remainingAttempts !== null && (
            <div
              className={`rounded-xl border p-3 text-center transition-all ${
                remainingAttempts > 0
                  ? "border-amber-200 bg-amber-50 text-amber-800"
                  : "border-rose-200 bg-rose-50 text-rose-800"
              }`}
            >
              <p className="text-xs font-semibold flex items-center justify-center gap-1.5">
                <i
                  className={
                    remainingAttempts > 0
                      ? "bi bi-exclamation-triangle-fill text-amber-600"
                      : "bi bi-x-circle-fill text-rose-600"
                  }
                />
                {remainingAttempts > 0
                  ? `${remainingAttempts} attempt${
                      remainingAttempts === 1 ? "" : "s"
                    } remaining before lock out.`
                  : "Maximum attempts reached. Please request a new code."}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              type="button"
              onClick={handleBackToLogin}
              disabled={isLoading || resending}
              className="out-secondary-btn flex items-center justify-center gap-1.5"
            >
              <i className="bi bi-arrow-left" />
              Back
            </button>

            <button
              type="submit"
              disabled={isLoading || resending || otp.length !== 6}
              className="out-submit-btn flex items-center justify-center gap-1.5"
            >
              {isLoading ? (
                <>
                  <i className="bi bi-arrow-repeat animate-spin text-base" />
                  Verifying...
                </>
              ) : (
                <>
                  <i className="bi bi-shield-check" />
                  Verify Code
                </>
              )}
            </button>
          </div>
        </form>

        {/* Resend Section */}
        <div className="mt-5 text-center">
          <button
            type="button"
            onClick={handleResend}
            disabled={isLoading || resending || countdown > 0}
            className="inline-flex items-center justify-center gap-2 text-xs font-semibold text-emerald-600 transition-colors hover:text-emerald-700 hover:underline disabled:cursor-not-allowed disabled:text-slate-400 disabled:no-underline"
          >
            <i
              className={
                resending
                  ? "bi bi-arrow-repeat animate-spin text-sm"
                  : "bi bi-arrow-counterclockwise text-sm"
              }
            />
            {resending
              ? "Sending new code..."
              : countdown > 0
              ? `Resend available in ${countdown}s`
              : "Didn't receive a code? Resend"}
          </button>
        </div>

        {/* Security Banner */}
        <div className="mt-5 rounded-xl border border-slate-100 bg-slate-50/80 p-3">
          <div className="flex items-center gap-2.5">
            <i className="bi bi-info-circle text-slate-400 text-sm shrink-0" />
            <p className="text-[11px] leading-4 text-slate-500">
              For security, verification codes expire quickly. Never share your passcode with anyone.
            </p>
          </div>
        </div>

        {/* Footer */}
        <Footer siteCopyright={siteCopyright} siteName={systemName} />
      </PageCard>
    </div>
  );
}

export default VerifyOtp;