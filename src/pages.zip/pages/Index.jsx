import React, { useRef, useState } from "react";
import ReCAPTCHA from "react-google-recaptcha";
import Swal from "sweetalert2";
import {
  showErrorAlert,
  showLoadingPopup,
  showSuccessAlert,
} from "../assets/js/swalHelpers";
import { useAppSettings } from "../assets/js/useAppSettings";
import {
  API_BASE_URL,
  ALLOWED_ACCOUNT_TYPES,
  isValidEmail,
} from "../assets/js/appConfig";
import { AuthPage, FormInput, SettingsLoading } from "./inc/PagesComponents";

import Maintenance from "./Maintenance";

// ==========================================================
// MAIN COMPONENT
// ==========================================================

function Index({ onLoginSuccess }) {
  const {
    settingsLoading,

    backgroundUrl,
    backgroundStyle,

    siteName,
    siteCopyright,

    logoUrl,

    showRegistration,
    showForgotPassword,
    showRecaptcha,
    recaptchaSiteKey,
    showOtp,
    showRememberMe,

    maxLoginAttempts,
    lockoutMinutes,

    maintenanceDateFormat,
    maintenanceTimeFormat,

    maintenanceTitle,
    maintenanceSubject,
    maintenanceStartTime,
    maintenanceEndTime,
    maintenanceMessage,
    isUnderMaintenance,
  } = useAppSettings();

  // ========================================================
  // MODE
  // ========================================================

  const [mode, setMode] = useState("login");

  const isLogin = mode === "login";

  // ========================================================
  // LOGIN
  // ========================================================

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  // ========================================================
  // SIGNUP
  // ========================================================

  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // ========================================================
  // GENERAL
  // ========================================================

  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const recaptchaRef = useRef(null);

  // ========================================================
  // API ERROR
  // ========================================================

  const getApiErrorMessage = (data, fallback) => {
    let message = data?.message || data?.detail || fallback;

    if (data?.errors && typeof data.errors === "object") {
      const firstError = Object.values(data.errors).flat().find(Boolean);

      if (firstError) {
        message = firstError;
      }
    }

    return message;
  };

  // ========================================================
  // CAPTCHA
  // ========================================================

  const getCaptchaValue = () => {
    if (!showRecaptcha || !recaptchaSiteKey) {
      return null;
    }

    return recaptchaRef.current?.getValue() || null;
  };

  // ========================================================
  // MODE
  // ========================================================

  const switchMode = (newMode) => {
    if (isLoading) {
      return;
    }

    recaptchaRef.current?.reset();

    setMode(newMode);
  };

  // ========================================================
  // REFRESH
  // ========================================================

  const handleRefresh = () => {
    if (isRefreshing) {
      return;
    }

    setIsRefreshing(true);

    window.setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  // ========================================================
  // FORGOT PASSWORD
  // ========================================================

  const handleForgotPassword = () => {
    if (isLoading) {
      return;
    }

    window.location.assign("/forgot-password");
  };

  // ========================================================
  // LOGIN
  // ========================================================

  const handleLogin = async () => {
    const email = username.trim().toLowerCase();

    if (!email) {
      showErrorAlert("Please enter your email address.");
      return;
    }

    if (!isValidEmail(email)) {
      showErrorAlert("Please enter a valid email address.");
      return;
    }

    if (!password) {
      showErrorAlert("Please enter your password.");
      return;
    }

    const captchaValue = getCaptchaValue();

    if (showRecaptcha && recaptchaSiteKey && !captchaValue) {
      showErrorAlert("Please complete the reCAPTCHA verification.");
      return;
    }

    setIsLoading(true);

    showLoadingPopup("Signing in...");

    try {
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          uacc_email: email,
          uacc_password: password,
          remember_me: rememberMe,
          recaptcha_token: captchaValue,
          otp_enabled: showOtp,
          login_max_attempts: maxLoginAttempts,
          login_lockout_minutes: lockoutMinutes,
        }),
      });

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      // EMAIL VERIFICATION
      if (response.status === 403 && data?.email_verification_required) {
        Swal.close();

        recaptchaRef.current?.reset();

        window.location.assign(
          `/verify-email?status=info&email=${encodeURIComponent(email)}`,
        );

        return;
      }

      // OTP
      if (data?.otp_required === true) {
        Swal.close();

        recaptchaRef.current?.reset();

        const otpEmail = data?.email || email;

        window.location.assign(
          `/verify-otp?email=${encodeURIComponent(otpEmail)}&remember_me=${
            rememberMe ? "1" : "0"
          }`,
        );

        return;
      }

      // ERROR
      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(data, "Invalid credentials provided."),
        );
      }

      // TOKEN
      const token = data?.access_token;

      if (!token) {
        throw new Error("Authentication token was not returned by the server.");
      }

      // USER
      const user = data?.user || data?.data?.user;

      if (!user) {
        throw new Error("User information was not returned by the server.");
      }

      // ROLE
      if (!ALLOWED_ACCOUNT_TYPES.includes(user?.uacc_type)) {
        throw new Error("Invalid account role configuration or type.");
      }

      // STATUS
      if (user?.uacc_status && user.uacc_status !== "Active") {
        throw new Error(
          "Your account is currently inactive. Please contact your system administrator.",
        );
      }

      // VERIFIED
      if (!user?.uacc_email_verified_at) {
        Swal.close();

        recaptchaRef.current?.reset();

        window.location.assign(
          `/verify-email?status=info&email=${encodeURIComponent(email)}`,
        );

        return;
      }

      // STORAGE
      const storage = rememberMe ? localStorage : sessionStorage;

      const authData = {
        access_token: token,
        auth_user: JSON.stringify(user),
        token_type: data?.token_type || "No Data Available.",
        uacc_type: user?.uacc_type || "",
        uacc_reference: user?.uacc_reference || "",
        uacc_email: user?.uacc_email || "",
        uacc_status: user?.uacc_status || "",
      };

      Object.keys(authData).forEach((key) => {
        localStorage.removeItem(key);
        sessionStorage.removeItem(key);
      });

      Object.entries(authData).forEach(([key, value]) => {
        storage.setItem(key, value);
      });

      localStorage.setItem("activeTab", "dashboard");

      recaptchaRef.current?.reset();

      showSuccessAlert("Login successful! Redirecting...", 1000);

      window.setTimeout(() => {
        onLoginSuccess?.(
          {
            ...data,
            user,
          },
          rememberMe,
        );
      }, 1000);
    } catch (error) {
      console.error("Login error:", error);

      Swal.close();

      showErrorAlert(error?.message || "An unexpected network error occurred.");

      recaptchaRef.current?.reset();
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================================
  // SIGNUP
  // ========================================================

  const handleSignup = async () => {
    const email = signupEmail.trim().toLowerCase();

    if (!email) {
      showErrorAlert("Please enter your email address.");
      return;
    }

    if (!isValidEmail(email)) {
      showErrorAlert("Please enter a valid email address.");
      return;
    }

    if (!signupPassword) {
      showErrorAlert("Please enter a password.");
      return;
    }

    if (signupPassword.length < 8) {
      showErrorAlert("Password must be at least 8 characters.");
      return;
    }

    if (!confirmPassword) {
      showErrorAlert("Please confirm your password.");
      return;
    }

    if (signupPassword !== confirmPassword) {
      showErrorAlert("Passwords do not match.");
      return;
    }

    const captchaValue = getCaptchaValue();

    if (showRecaptcha && recaptchaSiteKey && !captchaValue) {
      showErrorAlert("Please complete the reCAPTCHA verification.");
      return;
    }

    setIsLoading(true);

    showLoadingPopup("Creating account...");

    try {
      const response = await fetch(`${API_BASE_URL}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          uacc_email: email,
          uacc_password: signupPassword,
          uacc_password_confirmation: confirmPassword,
          recaptcha_token: captchaValue,
        }),
      });

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(data, "Unable to create your account."),
        );
      }

      recaptchaRef.current?.reset();

      setSignupPassword("");
      setConfirmPassword("");

      if (data?.email_verification_required) {
        Swal.close();

        window.location.assign(
          `/verify-email?status=info&email=${encodeURIComponent(email)}`,
        );

        return;
      }

      setSignupEmail("");

      showSuccessAlert(
        data?.message || "Account created successfully. Please sign in.",
        1200,
      );

      window.setTimeout(() => {
        setMode("login");
      }, 1200);
    } catch (error) {
      console.error("Registration error:", error);

      Swal.close();

      showErrorAlert(error?.message || "An unexpected network error occurred.");

      recaptchaRef.current?.reset();
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================================
  // FORM SUBMIT
  // ========================================================

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (settingsLoading) {
      return;
    }

    if (isUnderMaintenance) {
      showErrorAlert(
        "The system is currently under maintenance. Please try again later.",
      );
      return;
    }

    if (isLogin) {
      await handleLogin();
    } else {
      await handleSignup();
    }
  };

  // ========================================================
  // SETTINGS LOADING
  // ========================================================

  if (settingsLoading) {
    return <SettingsLoading />;
  }

  // ========================================================
  // MAINTENANCE
  // ========================================================

  if (isUnderMaintenance) {
    return (
      <Maintenance
        siteName={siteName}
        siteCopyright={siteCopyright}
        logoUrl={logoUrl}
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        maintenanceTitle={maintenanceTitle}
        maintenanceSubject={maintenanceSubject}
        maintenanceStartTime={maintenanceStartTime}
        maintenanceEndTime={maintenanceEndTime}
        maintenanceMessage={maintenanceMessage}
        maintenanceDateFormat={maintenanceDateFormat}
        maintenanceTimeFormat={maintenanceTimeFormat}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />
    );
  }

  // ========================================================
  // LOGIN / SIGNUP
  // ========================================================

  return (
    <AuthPage
      mode={mode}
      showRegistration={showRegistration}
      isLoading={isLoading}
      switchMode={switchMode}
      logoUrl={logoUrl}
      siteName={siteName}
      backgroundUrl={backgroundUrl}
      backgroundStyle={backgroundStyle}
      siteCopyright={siteCopyright}
    >
      <form onSubmit={handleSubmit} className="space-y-3.5">
        {/* ==================================================
            LOGIN
        ================================================== */}

        {isLogin && (
          <>
            <FormInput
              id="username"
              label="Email Address"
              icon="bi-envelope"
              type="email"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              placeholder="name@example.com"
              autoComplete="username"
              disabled={isLoading}
            />

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="password" className="out-label">
                  Password
                </label>

                {showForgotPassword && (
                  <button
                    type="button"
                    disabled={isLoading}
                    onClick={handleForgotPassword}
                    className="text-xs font-semibold text-emerald-600 transition-colors hover:text-emerald-700 hover:underline disabled:opacity-50"
                  >
                    Forgot password?
                  </button>
                )}
              </div>

              <FormInput
                id="password"
                icon="bi-lock"
                password
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                disabled={isLoading}
                showPassword={showPassword}
                onTogglePassword={() => setShowPassword((value) => !value)}
              />
            </div>

            {showRememberMe && (
              <div className="flex items-center">
                <input
                  id="remember"
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(event) => setRememberMe(event.target.checked)}
                  disabled={isLoading}
                  className="h-4 w-4 cursor-pointer rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500/20"
                />

                <label
                  htmlFor="remember"
                  className="ml-2 cursor-pointer select-none text-sm text-slate-600"
                >
                  Remember me
                </label>
              </div>
            )}
          </>
        )}

        {/* ==================================================
            SIGNUP
        ================================================== */}

        {!isLogin && showRegistration && (
          <>
            <FormInput
              id="signupEmail"
              label="Email Address"
              icon="bi-envelope"
              type="email"
              value={signupEmail}
              onChange={(event) => setSignupEmail(event.target.value)}
              placeholder="name@example.com"
              autoComplete="email"
              disabled={isLoading}
            />

            <div>
              <FormInput
                id="signupPassword"
                label="Password"
                icon="bi-lock"
                password
                value={signupPassword}
                onChange={(event) => setSignupPassword(event.target.value)}
                placeholder="Minimum 8 characters"
                autoComplete="new-password"
                disabled={isLoading}
                showPassword={showSignupPassword}
                onTogglePassword={() =>
                  setShowSignupPassword((value) => !value)
                }
              />

              <p className="mt-1 text-[11px] text-slate-400">
                Password must contain at least 8 characters.
              </p>
            </div>

            <div>
              <FormInput
                id="confirmPassword"
                label="Confirm Password"
                icon="bi-shield-lock"
                password
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                placeholder="Repeat your password"
                autoComplete="new-password"
                disabled={isLoading}
                showPassword={showConfirmPassword}
                onTogglePassword={() =>
                  setShowConfirmPassword((value) => !value)
                }
              />

              {confirmPassword && signupPassword === confirmPassword && (
                <p className="mt-1 text-[11px] font-semibold text-emerald-600">
                  <i className="bi bi-check-circle mr-1" />
                  Passwords match
                </p>
              )}
            </div>
          </>
        )}

        {/* ==================================================
            CAPTCHA
        ================================================== */}

        {showRecaptcha && recaptchaSiteKey && (
          <div className="flex justify-center overflow-hidden py-0.5">
            <div className="origin-left scale-[0.85] transform sm:origin-center sm:scale-100">
              <ReCAPTCHA
                ref={recaptchaRef}
                sitekey={recaptchaSiteKey}
                onExpired={() => recaptchaRef.current?.reset()}
                onErrored={() =>
                  showErrorAlert("Unable to connect to reCAPTCHA service.")
                }
              />
            </div>
          </div>
        )}

        {/* ==================================================
            SUBMIT
        ================================================== */}

        <button type="submit" disabled={isLoading} className="out-submit-btn">
          {isLoading ? (
            <>
              <i className="bi bi-arrow-repeat mr-2 animate-spin text-base" />

              <span>{isLogin ? "Signing in..." : "Creating account..."}</span>
            </>
          ) : (
            <>
              <i
                className={`bi ${
                  isLogin ? "bi-box-arrow-in-right" : "bi-person-plus"
                } mr-2 text-base`}
              />

              <span>{isLogin ? "Sign In" : "Create Account"}</span>
            </>
          )}
        </button>
      </form>
    </AuthPage>
  );
}

export default Index;
