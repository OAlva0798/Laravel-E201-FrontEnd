import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Swal from "sweetalert2";

import {
  showErrorAlert,
  showLoadingPopup,
  showSuccessAlert,
} from "../assets/js/swalHelpers";

import { useAppSettings } from "../assets/js/useAppSettings";

import { API_BASE_URL, isValidEmail } from "../assets/js/appConfig";

import {
  PageBackground,
  PageCard,
  SystemLogo,
  Footer,
  SettingsLoading,
} from "./inc/PagesComponents";

import Maintenance from "./Maintenance";

// ==========================================================
// EMAIL INPUT
// ==========================================================

function EmailInput({
  id = "email",
  value,
  onChange,
  disabled,
  autoFocus = false,
}) {
  return (
    <div>
      <label htmlFor={id} className="out-label">
        Email Address
      </label>

      <div className="group relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 transition-colors group-focus-within:text-emerald-600">
          <i className="bi bi-envelope text-base" />
        </span>

        <input
          id={id}
          name={id}
          type="email"
          value={value}
          onChange={onChange}
          placeholder="name@example.com"
          autoComplete="email"
          autoFocus={autoFocus}
          disabled={disabled}
          required
          className="out-input"
        />

        {value && !disabled && (
          <button
            type="button"
            onClick={() =>
              onChange({
                target: {
                  value: "",
                },
              })
            }
            aria-label="Clear email"
            className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 transition-colors hover:text-slate-600"
          >
            <i className="bi bi-x-circle-fill text-sm" />
          </button>
        )}
      </div>
    </div>
  );
}

// ==========================================================
// STATUS MESSAGE
// ==========================================================

function StatusMessage({ type, title, children }) {
  const config = {
    success: {
      wrapper: "border-emerald-100 bg-emerald-50/60",
      iconWrapper: "bg-emerald-100 text-emerald-600",
      icon: "bi-check-circle-fill",
      title: "text-emerald-900",
      text: "text-emerald-800",
    },

    already_verified: {
      wrapper: "border-emerald-100 bg-emerald-50/60",
      iconWrapper: "bg-emerald-100 text-emerald-600",
      icon: "bi-envelope-check",
      title: "text-emerald-900",
      text: "text-emerald-800",
    },

    error: {
      wrapper: "border-rose-100 bg-rose-50/60",
      iconWrapper: "bg-rose-100 text-rose-600",
      icon: "bi-x-circle",
      title: "text-rose-900",
      text: "text-rose-800",
    },
  };

  const current = config[type];

  if (!current) {
    return null;
  }

  return (
    <div className={`rounded-2xl border p-4 ${current.wrapper}`}>
      <div className="flex gap-3">
        <div
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${current.iconWrapper}`}
        >
          <i className={`bi ${current.icon} text-lg`} />
        </div>

        <div className="text-left">
          <h2 className={`font-bold ${current.title}`}>{title}</h2>

          <p className={`mt-1 text-sm leading-5 ${current.text}`}>{children}</p>
        </div>
      </div>
    </div>
  );
}

// ==========================================================
// VERIFICATION STEPS
// ==========================================================

function VerificationSteps() {
  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
      <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500">
        What happens next?
      </p>

      <div className="grid grid-cols-3 gap-2">
        <div className="text-center">
          <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-white text-emerald-600 shadow-sm">
            <i className="bi bi-envelope" />
          </div>

          <p className="mt-2 text-[10px] font-semibold text-slate-500">
            Enter email
          </p>
        </div>

        <div className="text-center">
          <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-white text-emerald-600 shadow-sm">
            <i className="bi bi-send" />
          </div>

          <p className="mt-2 text-[10px] font-semibold text-slate-500">
            Check inbox
          </p>
        </div>

        <div className="text-center">
          <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-white text-emerald-600 shadow-sm">
            <i className="bi bi-patch-check" />
          </div>

          <p className="mt-2 text-[10px] font-semibold text-slate-500">
            Verify email
          </p>
        </div>
      </div>
    </div>
  );
}

// ==========================================================
// MAIN COMPONENT
// ==========================================================

export default function VerifyEmail() {
  const [searchParams] = useSearchParams();

  // ========================================================
  // APP SETTINGS
  // ========================================================

  const {
    settingsLoading,

    siteName,
    siteCopyright,
    logoUrl,
    backgroundUrl,
    backgroundStyle,

    maintenanceDateFormat,
    maintenanceTimeFormat,

    maintenanceTitle,
    maintenanceSubject,
    maintenanceStartTime,
    maintenanceEndTime,
    maintenanceMessage,

    isUnderMaintenance,
  } = useAppSettings();

  // ========================================================
  // STATE
  // ========================================================

  const [status, setStatus] = useState("info");

  const [message, setMessage] = useState("");

  const [email, setEmail] = useState(searchParams.get("email") || "");

  const [isLoading, setIsLoading] = useState(false);

  const [isRefreshing, setIsRefreshing] = useState(false);

  // ========================================================
  // API ERROR
  // ========================================================

  const getApiErrorMessage = (data, fallback) => {
    let apiMessage = data?.message || data?.detail || fallback;

    if (data?.errors && typeof data.errors === "object") {
      const firstError = Object.values(data.errors).flat().find(Boolean);

      if (firstError) {
        apiMessage = firstError;
      }
    }

    return apiMessage;
  };

  // ========================================================
  // READ VERIFICATION STATUS
  // ========================================================

  useEffect(() => {
    const currentStatus = searchParams.get("status");

    const currentMessage = searchParams.get("message");

    const currentEmail = searchParams.get("email");

    if (currentEmail) {
      setEmail(currentEmail);
    }

    switch (currentStatus) {
      case "success":
        setStatus("success");

        setMessage("Your email address has been successfully verified.");

        break;

      case "already_verified":
        setStatus("already_verified");

        setMessage("Your email address has already been verified.");

        break;

      case "error":
        setStatus("error");

        setMessage(currentMessage || "Unable to verify your email address.");

        break;

      case "info":
        setStatus("info");

        setMessage(
          "Please check your email and click the verification link to activate your account.",
        );

        break;

      default:
        setStatus("info");

        setMessage(
          "Enter your email address and request a new verification link.",
        );

        break;
    }
  }, [searchParams]);

  // ========================================================
  // REFRESH
  // ========================================================

  const handleRefresh = () => {
    if (isRefreshing) return;

    setIsRefreshing(true);

    window.setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  // ========================================================
  // RESEND VERIFICATION
  // ========================================================

  const handleResend = async (event) => {
    event.preventDefault();

    if (settingsLoading) return;

    if (isUnderMaintenance) {
      showErrorAlert(
        "The system is currently under maintenance. Please try again later.",
      );

      return;
    }

    const normalizedEmail = email.trim().toLowerCase();

    // ------------------------------------------------------
    // VALIDATION
    // ------------------------------------------------------

    if (!normalizedEmail) {
      showErrorAlert("Please enter the email address linked to your account.");

      return;
    }

    if (!isValidEmail(normalizedEmail)) {
      showErrorAlert("Please enter a valid email address.");

      return;
    }

    setIsLoading(true);

    showLoadingPopup("Sending verification email...");

    try {
      const response = await fetch(`${API_BASE_URL}/email/resend`, {
        method: "POST",

        headers: {
          "Content-Type": "application/json",

          Accept: "application/json",
        },

        body: JSON.stringify({
          uacc_email: normalizedEmail,
        }),
      });

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      // ----------------------------------------------------
      // ACCOUNT NOT FOUND
      // ----------------------------------------------------

      if (response.status === 404) {
        Swal.close();

        showErrorAlert(
          data?.message ||
            "We couldn't find an account with that email address.",
        );

        return;
      }

      // ----------------------------------------------------
      // ACCOUNT NOT ALLOWED
      // ----------------------------------------------------

      if (response.status === 403) {
        Swal.close();

        showErrorAlert(
          data?.message ||
            "Verification email cannot be sent for this account.",
        );

        return;
      }

      // ----------------------------------------------------
      // OTHER ERRORS
      // ----------------------------------------------------

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(
            data,
            "We couldn't send the verification email right now. Please try again.",
          ),
        );
      }

      // ----------------------------------------------------
      // SUCCESS
      // ----------------------------------------------------

      Swal.close();

      showSuccessAlert(
        data?.message ||
          "A new verification email has been sent to your email address.",
        4500,
      );

      setStatus("info");

      setMessage(
        "A new verification link has been sent. Please check your email and click the link to verify your account.",
      );
    } catch (error) {
      console.error("Resend verification email error:", error);

      Swal.close();

      showErrorAlert(
        error?.message ||
          "We couldn't connect to the server. Please check your connection and try again.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================================
  // BACK TO LOGIN
  // ========================================================

  const handleBackToLogin = () => {
    window.location.assign("/");
  };

  // ========================================================
  // SETTINGS LOADING
  // ========================================================

  if (settingsLoading) {
    return <SettingsLoading />;
  }

  // ========================================================
  // MAINTENANCE
  // ========================================================

  if (isUnderMaintenance) {
    return (
      <Maintenance
        siteName={siteName}
        siteCopyright={siteCopyright}
        logoUrl={logoUrl}
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        maintenanceTitle={maintenanceTitle}
        maintenanceSubject={maintenanceSubject}
        maintenanceStartTime={maintenanceStartTime}
        maintenanceEndTime={maintenanceEndTime}
        maintenanceMessage={maintenanceMessage}
        maintenanceDateFormat={maintenanceDateFormat}
        maintenanceTimeFormat={maintenanceTimeFormat}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />
    );
  }

  // ========================================================
  // PAGE
  // ========================================================

  const systemName = siteName || "System Portal";

  return (
    <div className="out-page-container" style={backgroundStyle}>
      <PageBackground
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
      />

      <PageCard>
        {/* ==================================================
            HEADER
        ================================================== */}

        <div className="mb-2 text-center">
          <SystemLogo logoUrl={logoUrl} siteName={systemName} />

          <div className="mb-1 inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-emerald-700">
            <i className="bi bi-shield-check" />
            Email Verification
          </div>

          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            Verify Your Email
          </h1>

          <p className="mt-1 text-xs font-medium leading-5 text-slate-500 sm:text-sm">
            {message}
          </p>
        </div>

        {/* ==================================================
            SUCCESS
        ================================================== */}

        {status === "success" && (
          <div className="mt-4">
            <StatusMessage type="success" title="Email Verified">
              Your account email has been successfully verified. You can now
              sign in to your account.
            </StatusMessage>

            <div className="mt-4">
              <button
                type="button"
                onClick={handleBackToLogin}
                className="out-submit-btn"
              >
                <i className="bi bi-box-arrow-in-right text-base" />
                Continue to Sign In
              </button>
            </div>
          </div>
        )}

        {/* ==================================================
            ALREADY VERIFIED
        ================================================== */}

        {status === "already_verified" && (
          <div className="mt-4">
            <StatusMessage type="already_verified" title="Already Verified">
              This email address has already been verified. You can sign in to
              your account.
            </StatusMessage>

            <div className="mt-4">
              <button
                type="button"
                onClick={handleBackToLogin}
                className="out-submit-btn"
              >
                <i className="bi bi-box-arrow-in-right text-base" />
                Continue to Sign In
              </button>
            </div>
          </div>
        )}

        {/* ==================================================
            INFO
        ================================================== */}

        {status === "info" && (
          <div className="mt-4">
            <form onSubmit={handleResend}>
              <EmailInput
                id="verifyEmail"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                disabled={isLoading}
                autoFocus
              />

              <p className="mt-1.5 flex items-start gap-1.5 text-[11px] text-slate-400">
                <i className="bi bi-info-circle mt-0.5" />
                Use the email address registered with your account.
              </p>

              <div className="mt-4">
                <VerificationSteps />
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={handleBackToLogin}
                  className="out-secondary-btn"
                >
                  <i className="bi bi-arrow-left" />
                  Back to Sign In
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="out-submit-btn"
                >
                  {isLoading ? (
                    <>
                      <i className="bi bi-arrow-repeat animate-spin text-base" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-envelope-arrow-up text-base" />
                      Resend Link
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ==================================================
            ERROR
        ================================================== */}

        {status === "error" && (
          <div className="mt-4">
            <StatusMessage type="error" title="Verification Failed">
              {message}
            </StatusMessage>

            <form onSubmit={handleResend} className="mt-4">
              <EmailInput
                id="errorEmail"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                disabled={isLoading}
              />

              <div className="mt-4 grid grid-cols-2 gap-3">
                <button
                  type="button"
                  disabled={isLoading}
                  onClick={handleBackToLogin}
                  className="out-secondary-btn"
                >
                  <i className="bi bi-arrow-left" />
                  Back
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="out-submit-btn"
                >
                  {isLoading ? (
                    <>
                      <i className="bi bi-arrow-repeat animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-envelope-arrow-up" />
                      Send New Link
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ==================================================
            FOOTER
        ================================================== */}

        <Footer siteCopyright={siteCopyright} siteName={systemName} />
      </PageCard>
    </div>
  );
}
