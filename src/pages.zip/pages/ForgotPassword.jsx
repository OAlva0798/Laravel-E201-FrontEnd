import React, { useState } from "react";
import Swal from "sweetalert2";

import {
  showErrorAlert,
  showLoadingPopup,
  showSuccessAlert,
} from "../assets/js/swalHelpers";

import { useAppSettings } from "../assets/js/useAppSettings";

import { API_BASE_URL, isValidEmail } from "../assets/js/appConfig";

import {
  PageBackground,
  PageCard,
  SystemLogo,
  Footer,
  SettingsLoading,
} from "./inc/PagesComponents";

import Maintenance from "./Maintenance";

// ==========================================================
// EMAIL INPUT
// ==========================================================

function EmailInput({ email, setEmail, disabled }) {
  return (
    <div>
      <label htmlFor="email" className="out-label">
        Email Address
      </label>

      <div className="group relative">
        <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 transition-colors group-focus-within:text-emerald-600">
          <i className="bi bi-envelope text-base" />
        </span>

        <input
          id="email"
          name="email"
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="you@example.com"
          autoComplete="email"
          autoFocus
          disabled={disabled}
          required
          className="out-input"
        />

        {email && !disabled && (
          <button
            type="button"
            onClick={() => setEmail("")}
            className="absolute inset-y-0 right-0 flex items-center pr-4 text-slate-400 transition-colors hover:text-slate-600"
            aria-label="Clear email"
          >
            <i className="bi bi-x-circle-fill" />
          </button>
        )}
      </div>

      <p className="mt-2 flex items-start gap-1.5 text-xs text-slate-400">
        <i className="bi bi-info-circle mt-0.5" />
        Use the email address registered with your account.
      </p>
    </div>
  );
}

// ==========================================================
// WHAT HAPPENS NEXT
// ==========================================================

function ResetSteps() {
  const steps = [
    {
      icon: "bi-envelope",
      label: "Enter email",
    },
    {
      icon: "bi-send",
      label: "Check inbox",
    },
    {
      icon: "bi-key",
      label: "Reset password",
    },
  ];

  return (
    <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
      <p className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-500">
        What happens next?
      </p>

      <div className="grid grid-cols-3 gap-2">
        {steps.map((step) => (
          <div key={step.label} className="text-center">
            <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-white text-emerald-600 shadow-sm">
              <i className={`bi ${step.icon}`} />
            </div>

            <p className="mt-2 text-[10px] font-semibold text-slate-500">
              {step.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==========================================================
// SUCCESS STATE
// ==========================================================

function SuccessState({ email, onTryAnother }) {
  return (
    <div className="mt-6">
      <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
        <div className="flex gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
            <i className="bi bi-envelope-check text-lg" />
          </div>

          <div>
            <h2 className="text-sm font-bold text-emerald-900">
              Check your inbox
            </h2>

            <p className="mt-1 text-xs leading-5 text-emerald-800">
              If the email is associated with an account, password reset
              instructions will be sent there.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
        <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
          Email address
        </p>

        <p className="mt-1 truncate text-sm font-semibold text-slate-700">
          {email}
        </p>
      </div>

      <div className="mt-4 space-y-2">
        <p className="text-xs font-semibold text-slate-500">
          Didn't receive an email?
        </p>

        <ul className="space-y-1.5 text-xs text-slate-500">
          <li className="flex gap-2">
            <i className="bi bi-check-circle-fill mt-0.5 text-emerald-500" />
            Check your spam or junk folder.
          </li>

          <li className="flex gap-2">
            <i className="bi bi-check-circle-fill mt-0.5 text-emerald-500" />
            Make sure you entered the correct email address.
          </li>

          <li className="flex gap-2">
            <i className="bi bi-check-circle-fill mt-0.5 text-emerald-500" />
            Wait a few minutes before requesting another link.
          </li>
        </ul>
      </div>

      <button
        type="button"
        onClick={onTryAnother}
        className="out-secondary-btn"
      >
        <i className="bi bi-arrow-repeat" />
        Try Another Email
      </button>
    </div>
  );
}

// ==========================================================
// MAIN COMPONENT
// ==========================================================

export default function ForgotPassword() {
  const {
    settingsLoading,

    siteName,
    siteCopyright,
    logoUrl,
    backgroundUrl,
    backgroundStyle,

    maintenanceDateFormat,
    maintenanceTimeFormat,

    maintenanceTitle,
    maintenanceSubject,
    maintenanceStartTime,
    maintenanceEndTime,
    maintenanceMessage,

    isUnderMaintenance,
  } = useAppSettings();

  // ========================================================
  // SETTINGS
  // ========================================================

  const systemName = siteName || "System Portal";

  // ========================================================
  // STATE
  // ========================================================

  const [email, setEmail] = useState("");

  const [isLoading, setIsLoading] = useState(false);

  const [submitted, setSubmitted] = useState(false);

  const [isRefreshing, setIsRefreshing] = useState(false);

  // ========================================================
  // API ERROR
  // ========================================================

  const getApiErrorMessage = (data, fallback) => {
    let message = data?.message || data?.detail || fallback;

    if (data?.errors && typeof data.errors === "object") {
      const firstError = Object.values(data.errors).flat().find(Boolean);

      if (firstError) {
        message = firstError;
      }
    }

    return message;
  };

  // ========================================================
  // REFRESH
  // ========================================================

  const handleRefresh = () => {
    if (isRefreshing) {
      return;
    }

    setIsRefreshing(true);

    window.setTimeout(() => {
      window.location.reload();
    }, 300);
  };

  // ========================================================
  // SUBMIT
  // ========================================================

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (settingsLoading) {
      return;
    }

    if (isUnderMaintenance) {
      showErrorAlert(
        "The system is currently under maintenance. Please try again later.",
      );

      return;
    }

    const normalizedEmail = email.trim().toLowerCase();

    // ------------------------------------------------------
    // VALIDATION
    // ------------------------------------------------------

    if (!normalizedEmail) {
      showErrorAlert("Please enter the email address linked to your account.");

      return;
    }

    if (!isValidEmail(normalizedEmail)) {
      showErrorAlert("Please enter a valid email address.");

      return;
    }

    setIsLoading(true);

    showLoadingPopup("Sending password reset instructions...");

    try {
      const response = await fetch(`${API_BASE_URL}/forgot-password`, {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },

        body: JSON.stringify({
          uacc_email: normalizedEmail,
        }),
      });

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      // ----------------------------------------------------
      // EMAIL DOES NOT EXIST
      // ----------------------------------------------------

      if (response.status === 404) {
        Swal.close();

        showErrorAlert(
          data?.message ||
            "We couldn't find an account with that email address.",
        );

        return;
      }

      // ----------------------------------------------------
      // ACCOUNT NOT ALLOWED
      // ----------------------------------------------------

      if (response.status === 403) {
        Swal.close();

        showErrorAlert(
          data?.message || "Password reset is not available for this account.",
        );

        return;
      }

      // ----------------------------------------------------
      // OTHER API ERRORS
      // ----------------------------------------------------

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(
            data,
            "We couldn't process your request right now. Please try again.",
          ),
        );
      }

      // ----------------------------------------------------
      // SUCCESS
      // ----------------------------------------------------

      Swal.close();

      setSubmitted(true);

      showSuccessAlert(
        data?.message ||
          "Password reset instructions have been sent to your email.",
        4500,
      );
    } catch (error) {
      console.error("Forgot password error:", error);

      Swal.close();

      showErrorAlert(
        error?.message ||
          "We couldn't connect to the server. Please check your connection and try again.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  // ========================================================
  // BACK TO LOGIN
  // ========================================================

  const handleBackToLogin = () => {
    window.location.assign("/");
  };

  // ========================================================
  // SETTINGS LOADING
  // ========================================================

  if (settingsLoading) {
    return <SettingsLoading />;
  }

  // ========================================================
  // MAINTENANCE
  // ========================================================

  if (isUnderMaintenance) {
    return (
      <Maintenance
        siteName={siteName}
        siteCopyright={siteCopyright}
        logoUrl={logoUrl}
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        maintenanceTitle={maintenanceTitle}
        maintenanceSubject={maintenanceSubject}
        maintenanceStartTime={maintenanceStartTime}
        maintenanceEndTime={maintenanceEndTime}
        maintenanceMessage={maintenanceMessage}
        maintenanceDateFormat={maintenanceDateFormat}
        maintenanceTimeFormat={maintenanceTimeFormat}
        onRefresh={handleRefresh}
        isRefreshing={isRefreshing}
      />
    );
  }

  // ========================================================
  // PAGE
  // ========================================================

  return (
    <div className="out-page-container" style={backgroundStyle}>
      <PageBackground backgroundUrl={backgroundUrl} />

      <PageCard>
        {/* ==================================================
            HEADER
        ================================================== */}

        <div className="text-center">
          <SystemLogo logoUrl={logoUrl} siteName={systemName} />

          <div className="mt-2">
            <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-emerald-700">
              <i className="bi bi-shield-check" />
              Account Recovery
            </div>

            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-slate-900">
              Forgot your password?
            </h1>

            <p className="mx-auto mt-2 max-w-sm text-sm leading-5 text-slate-500">
              No worries. Enter the email address associated with your account
              and we'll help you get back in.
            </p>
          </div>
        </div>

        {/* ==================================================
            SUCCESS STATE
        ================================================== */}

        {submitted ? (
          <SuccessState
            email={email}
            onTryAnother={() => {
              setSubmitted(false);
              setEmail("");
            }}
          />
        ) : (
          /* ==================================================
             FORM
          ================================================== */

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <EmailInput
              email={email}
              setEmail={setEmail}
              disabled={isLoading}
            />

            <ResetSteps />

            {/* =================================================
                ACTION BUTTONS
            ================================================= */}

            <div className="grid grid-cols-2 gap-3 pt-1">
              {/* BACK TO LOGIN */}

              <button
                type="button"
                disabled={isLoading}
                onClick={handleBackToLogin}
                className="out-secondary-btn"
              >
                <i className="bi bi-arrow-left" />
                Back to Sign In
              </button>

              {/* SEND RESET LINK */}

              <button
                type="submit"
                disabled={isLoading}
                className="out-submit-btn"
              >
                {isLoading ? (
                  <>
                    <i className="bi bi-arrow-repeat animate-spin text-base" />
                    Sending...
                  </>
                ) : (
                  <>
                    <i className="bi bi-envelope-arrow-up text-base" />
                    Send Reset Link
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* ==================================================
            FOOTER
        ================================================== */}

        <Footer siteCopyright={siteCopyright} siteName={systemName} />
      </PageCard>
    </div>
  );
}
