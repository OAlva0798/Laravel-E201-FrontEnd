import React from "react";

import {
  formatDateTime,
  PageBackground,
  PageCard,
  SystemLogo,
  Footer,
} from "./inc/PagesComponents";

// ==========================================================
// MAINTENANCE SCHEDULE
// ==========================================================

function MaintenanceSchedule({
  startTime,
  endTime,
  maintenanceDateFormat,
  maintenanceTimeFormat,
}) {
  const start = formatDateTime(
    startTime,
    maintenanceDateFormat,
    maintenanceTimeFormat,
  );

  const end = formatDateTime(
    endTime,
    maintenanceDateFormat,
    maintenanceTimeFormat,
  );

  if (!start && !end) {
    return null;
  }

  return (
    <div className="mt-5">
      <div
        className={`grid gap-3 ${
          start && end
            ? "grid-cols-2"
            : "grid-cols-1"
        }`}
      >
        {start && (
          <div className="rounded-2xl border border-blue-200/80 bg-blue-50/60 p-3.5 text-center shadow-xs">
            <span className="text-sm font-bold uppercase tracking-wider text-blue-700">
              Started At
            </span>

            <span className="block text-xs font-medium text-blue-700">
              {start.date}
            </span>

            <span className="mt-1 block text-sm font-bold text-blue-900">
              {start.time}
            </span>
          </div>
        )}

        {end && (
          <div className="rounded-2xl border border-rose-200/80 bg-rose-50/60 p-3.5 text-center shadow-xs">
            <span className="text-sm font-bold uppercase tracking-wider text-rose-700">
              Expected End
            </span>

            <span className="block text-xs font-medium text-rose-700">
              {end.date}
            </span>

            <span className="mt-1 block text-sm font-bold text-rose-900">
              {end.time}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================================
// MAINTENANCE PAGE
// ==========================================================

export default function Maintenance({
  siteName,
  siteCopyright,
  logoUrl,
  backgroundUrl,
  backgroundStyle,
  maintenanceTitle,
  maintenanceSubject,
  maintenanceStartTime,
  maintenanceEndTime,
  maintenanceMessage,
  maintenanceDateFormat,
  maintenanceTimeFormat,
  onRefresh,
  isRefreshing,
}) {
  return (
    <div
      className="out-page-container"
      style={backgroundStyle}
    >
      <PageBackground
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
        darkOverlay
      />

      <PageCard>
        {/* HEADER */}
        <div className="text-center">
          <SystemLogo
            logoUrl={logoUrl}
            siteName={siteName}
            maintenance
          />

          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            {maintenanceTitle}
          </h1>

          <p className="mt-1 text-xs font-medium text-slate-500 sm:text-sm">
            {siteName}
          </p>
        </div>

        {/* SCHEDULE */}
        <MaintenanceSchedule
          startTime={maintenanceStartTime}
          endTime={maintenanceEndTime}
          maintenanceDateFormat={maintenanceDateFormat}
          maintenanceTimeFormat={maintenanceTimeFormat}
        />

        {/* MESSAGE */}
        <div className="m-5 rounded-2xl border border-emerald-100 bg-emerald-50/60 px-4 py-4">
          <p className="text-sm font-bold uppercase tracking-wider text-emerald-700">
            {maintenanceSubject}
          </p>

          <p className="mt-1 text-sm leading-5 text-slate-600">
            {maintenanceMessage}
          </p>
        </div>

        {/* REFRESH */}
        <button
          type="button"
          onClick={onRefresh}
          disabled={isRefreshing}
          className="out-submit-btn"
        >
          <i
            className={`bi ${
              isRefreshing
                ? "bi-arrow-repeat animate-spin"
                : "bi-arrow-clockwise"
            } text-base`}
          />

          <span>
            {isRefreshing
              ? "Checking..."
              : "Check Again"}
          </span>
        </button>

        <Footer
          siteCopyright={siteCopyright}
          siteName={siteName}
        />
      </PageCard>
    </div>
  );
}