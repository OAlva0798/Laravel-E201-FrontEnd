import React from "react";

// ==========================================================
// MODE TABS
// ==========================================================
export const MODE_TABS = [
  {
    mode: "login",
    icon: "bi-box-arrow-in-right",
    label: "Sign In",
  },
  {
    mode: "signup",
    icon: "bi-person-plus",
    label: "Sign Up",
  },
];

// ==========================================================
// DATE / TIME FORMATTER
// ==========================================================
export const formatDateTime = (
  dateStr,
  dateFormat = "M d, Y",
  timeFormat = "h:i A",
) => {
  if (!dateStr) {
    return null;
  }

  const dateObj = new Date(dateStr);

  if (Number.isNaN(dateObj.getTime())) {
    return null;
  }

  const pad = (value) => String(value).padStart(2, "0");

  const hours24 = dateObj.getHours();
  const hours12 = hours24 % 12 || 12;

  const replacements = {
    Y: dateObj.getFullYear(),
    y: String(dateObj.getFullYear()).slice(-2),

    m: pad(dateObj.getMonth() + 1),
    n: dateObj.getMonth() + 1,

    F: dateObj.toLocaleDateString("en-US", {
      month: "long",
    }),

    M: dateObj.toLocaleDateString("en-US", {
      month: "short",
    }),

    d: pad(dateObj.getDate()),
    j: dateObj.getDate(),

    H: pad(hours24),
    G: hours24,

    h: pad(hours12),
    g: hours12,

    i: pad(dateObj.getMinutes()),
    s: pad(dateObj.getSeconds()),

    A: hours24 >= 12 ? "PM" : "AM",
    a: hours24 >= 12 ? "pm" : "am",
  };

  const applyFormat = (format) => {
    if (!format) {
      return "";
    }

    return String(format).replace(
      /Y|y|F|M|m|n|d|j|H|G|h|g|i|s|A|a/g,
      (token) => replacements[token] ?? token,
    );
  };

  return {
    date: applyFormat(dateFormat),
    time: applyFormat(timeFormat),
  };
};

// ==========================================================
// BACKGROUND
// ==========================================================
export function PageBackground({ backgroundUrl, darkOverlay = false }) {
  return (
    <>
      {backgroundUrl ? (
        <div
          className={`absolute inset-0 ${
            darkOverlay ? "bg-slate-950/45" : "bg-slate-950/45"
          }`}
        />
      ) : (
        <>
          <div className="pointer-events-none absolute -right-40 -top-40 h-96 w-96 rounded-full bg-emerald-200/50 blur-3xl" />

          <div className="pointer-events-none absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-teal-200/40 blur-3xl" />

          {darkOverlay && (
            <div className="pointer-events-none absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-100/30 blur-3xl" />
          )}
        </>
      )}
    </>
  );
}

// ==========================================================
// CARD
// ==========================================================
export function PageCard({ children }) {
  return (
    <div className="out-card">
      <div className="out-card-inner">{children}</div>
    </div>
  );
}

// ==========================================================
// LOGO
// ==========================================================
export function SystemLogo({ logoUrl, siteName, maintenance = false }) {
  return (
    <div
      className={
        maintenance
          ? "mx-auto mb-3 flex h-20 w-20 items-center justify-center"
          : "mx-auto flex h-20 w-20 items-center justify-center"
      }
    >
      {logoUrl ? (
        <img
          src={logoUrl}
          alt={`${siteName} Logo`}
          className="max-h-full max-w-full object-contain"
          onError={(event) => {
            event.currentTarget.style.display = "none";
          }}
        />
      ) : (
        <div
          className={
            maintenance
              ? "flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600"
              : "flex h-16 w-16 items-center justify-center"
          }
        >
          <i
            className={
              maintenance
                ? "bi bi-tools text-3xl"
                : "bi bi-gear-wide-connected text-4xl text-emerald-400"
            }
          />
        </div>
      )}
    </div>
  );
}

// ==========================================================
// FORM INPUT
// ==========================================================
export function FormInput({
  id,
  label,
  icon,
  type = "text",
  value,
  onChange,
  placeholder,
  autoComplete,
  disabled,
  required = true,
  password = false,
  showPassword = false,
  onTogglePassword,
}) {
  return (
    <div>
      {label && (
        <label htmlFor={id} className="out-label">
          {label}
        </label>
      )}

      <div className="group relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 transition-colors group-focus-within:text-emerald-600">
          <i className={`bi ${icon} text-base`} />
        </span>

        <input
          id={id}
          name={id}
          type={password ? (showPassword ? "text" : "password") : type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          autoComplete={autoComplete}
          disabled={disabled}
          required={required}
          className="out-input"
        />

        {password && (
          <button
            type="button"
            onClick={onTogglePassword}
            disabled={disabled}
            aria-label={showPassword ? "Hide password" : "Show password"}
            className="absolute inset-y-0 right-0 flex items-center pr-3.5 text-slate-400 transition-colors hover:text-slate-600 disabled:cursor-not-allowed"
          >
            <i
              className={
                showPassword
                  ? "bi bi-eye-slash text-base"
                  : "bi bi-eye text-base"
              }
            />
          </button>
        )}
      </div>
    </div>
  );
}

// ==========================================================
// SETTINGS LOADING
// ==========================================================
export function SettingsLoading() {
  return (
    <div className="out-page-container">
      <PageBackground />

      <div className="flex flex-col items-center justify-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600">
          <i className="bi bi-arrow-repeat animate-spin text-xl" />
        </div>

        <p className="mt-3 text-sm font-semibold text-slate-600">
          Checking system status...
        </p>

        <p className="mt-1 text-xs text-slate-400">Please wait</p>
      </div>
    </div>
  );
}

// ==========================================================
// AUTH PAGE
// ==========================================================
export function AuthPage({
  mode,
  showRegistration,
  isLoading,
  switchMode,
  children,
  logoUrl,
  siteName,
  backgroundUrl,
  backgroundStyle,
  siteCopyright,
}) {
  const isLogin = mode === "login";

  return (
    <div className="out-page-container" style={backgroundStyle}>
      <PageBackground
        backgroundUrl={backgroundUrl}
        backgroundStyle={backgroundStyle}
      />

      <PageCard>
        <div className="mb-2 text-center">
          <SystemLogo logoUrl={logoUrl} siteName={siteName} />

          <h1 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            {isLogin ? "Welcome Back" : "Create Account"}
          </h1>

          <p className="mt-1 text-xs font-medium text-slate-500 sm:text-sm">
            {isLogin
              ? "Secure portal access. Please enter your credentials."
              : `Register for ${siteName || "the system"}`}
          </p>
        </div>

        {showRegistration && (
          <div className="mb-2 grid grid-cols-2 rounded-2xl bg-slate-100 p-1">
            {MODE_TABS.map((item) => {
              const active = mode === item.mode;

              return (
                <button
                  key={item.mode}
                  type="button"
                  disabled={isLoading}
                  onClick={() => switchMode(item.mode)}
                  className={`rounded-xl px-3 py-2 text-xs font-bold transition-all ${
                    active
                      ? "bg-white text-emerald-600 shadow-sm"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  <i className={`bi ${item.icon} mr-1.5`} />

                  {item.label}
                </button>
              );
            })}
          </div>
        )}

        {children}

        <Footer siteCopyright={siteCopyright} siteName={siteName} />
      </PageCard>
    </div>
  );
}

// ==========================================================
// FOOTER
// ==========================================================
export function Footer({ siteCopyright, siteName }) {
  return (
    <div className="mt-2 pt-4 text-center">
      <p className="text-xs text-slate-400">
        &copy; {siteCopyright} {siteName}. All rights reserved.
      </p>
    </div>
  );
}