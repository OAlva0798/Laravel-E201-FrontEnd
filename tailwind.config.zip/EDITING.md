# Editing guide

| I want to change...            | Edit this file                          |
|--------------------------------|-----------------------------------------|
| App name / theme               | src/config/site.config.js (SITE)        |
| API address                    | .env  (VITE_API_BASE_URL)               |
| Which role sees which page     | src/config/site.config.js (ROLE_TABS) + src/assets/js/roleAccess.js |
| Calling the API                | import { apiGet, apiPost } from src/lib/http.js |
| Reading the login token        | import { getToken } from src/lib/auth.js |
| Showing admin-written HTML     | <SafeHtml html={...} /> — never dangerouslySetInnerHTML |

## Security rules baked in
1. Token: sessionStorage by default; localStorage only if "Remember me".
2. All DB-authored HTML goes through an allow-list sanitizer (no scripts, handlers, styles, javascript: links).
3. No hardcoded server URLs; backup calls send the auth token.
4. CSP + referrer policy in index.html. .env is git-ignored.
5. UI role checks only hide buttons. The backend MUST enforce roles on every endpoint.

## Shared data (src/data/OrgDataContext.jsx)
One cached store for company / center / department / position / position level.
- Add another shared list: add one line to `ORG`.
- In a component: `const { center } = useOrgData("center")` → `center.list / .options / .map / .loading`.
- Outside React: `loadOrgList("center")` (employeeShared.js) – same cache.
- Cache lasts 1 min, refreshes automatically after any save/delete in CrudManager, and is wiped on sign-out.
- Not yet migrated: Profile.jsx, DepartmentPositionContent.jsx (they still fetch their own copies).

## "This content is blocked" message
Caused by the Content-Security-Policy. It is built in `vite.config.js` (production build only; dev is never blocked).
Add the missing source to the matching line: `frame-src` (iframes/previews), `img-src`, `media-src`, `connect-src` (API calls).
For stronger protection also send the same policy as an HTTP header from your web server.
