import { useCallback, useEffect, useMemo, useState } from "react";
import { apiRequest, extractList, getErrorMessage, getFullName, getInitials } from "./Employees/employeeShared";
import { useOrgData } from "../data/OrgDataContext";
import { getStoredUser } from "../lib/auth";
import { hasRoleAccess } from "../assets/js/roleAccess";
import {
  STATUS_CARDS, UPCOMING_WINDOWS, countByStatus, hasStatus, upcomingDates,
  hireDate, dayLabel, formatDate,
} from "./dashboardUtils";

const PAGE = 50; // rows shown before "Show more"

// ---------- small building blocks ----------
function StatCard({ label, icon, count, active, loading, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`group relative overflow-hidden rounded-2xl border p-4 text-left shadow-sm transition
        focus:outline-none focus-visible:ring-4 focus-visible:ring-gold-300
        ${active ? "border-navy-700 bg-navy-700 text-white" : "border-slate-200 bg-white hover:border-gold-400 hover:shadow-md"}`}
    >
      <span className={`absolute inset-x-0 top-0 h-1 ${active ? "bg-gold-500" : "bg-gold-400/0 group-hover:bg-gold-400"}`} />
      <div className="flex items-center justify-between gap-2">
        <span className={`text-[11px] font-bold uppercase tracking-wider ${active ? "text-gold-200" : "text-slate-500"}`}>{label}</span>
        <i className={`bi ${icon} text-lg ${active ? "text-gold-400" : "text-gold-600"}`} />
      </div>
      <p className={`mt-2 text-3xl font-extrabold tabular-nums ${active ? "text-white" : "text-navy-800"}`}>
        {loading ? <span className="inline-block h-8 w-12 animate-pulse rounded bg-slate-200/70" /> : count}
      </p>
    </button>
  );
}

function Avatar({ emp, tone = "navy" }) {
  const tones = { navy: "bg-navy-100 text-navy-800", gold: "bg-gold-100 text-gold-800" };
  return (
    <span className={`flex size-10 shrink-0 items-center justify-center rounded-full text-xs font-bold ${tones[tone]}`}>
      {getInitials(getFullName(emp, ""))}
    </span>
  );
}

function Panel({ title, icon, right, children }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3 sm:px-5">
        <h2 className="flex items-center gap-2 text-sm font-bold text-navy-800">
          <i className={`bi ${icon} text-gold-600`} /> {title}
        </h2>
        {right}
      </header>
      {children}
    </section>
  );
}

function UpcomingList({ rows, empty, tone, icon, badge, sub }) {
  if (!rows.length) return <p className="px-5 py-10 text-center text-sm text-slate-400">{empty}</p>;
  return (
    <ul className="max-h-96 divide-y divide-slate-100 overflow-y-auto">
      {rows.map(({ emp, date, days, years }) => (
        <li key={`${emp.ee_id_number}-${emp.ee_lastname}-${date.getTime()}`} className="flex items-center gap-3 px-4 py-3 sm:px-5">
          <Avatar emp={emp} tone={tone} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-navy-900">{getFullName(emp)}</p>
            <p className="truncate text-xs text-slate-500">{sub(emp, years)}</p>
          </div>
          <div className="shrink-0 text-right">
            <p className="text-sm font-bold text-navy-800">
              <i className={`bi ${icon} mr-1 text-gold-600`} />
              {date.toLocaleDateString(undefined, { month: "short", day: "numeric" })}
            </p>
            <span className={`mt-0.5 inline-block rounded-full px-2 py-0.5 text-[11px] font-semibold ${days === 0 ? "bg-gold-500 text-navy-950" : "bg-navy-50 text-navy-700"}`}>
              {badge(days, years)}
            </span>
          </div>
        </li>
      ))}
    </ul>
  );
}

// ---------- main screen ----------
function EmployeeDashboard() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState(STATUS_CARDS[0].value);
  const [search, setSearch] = useState("");
  const [windowDays, setWindowDays] = useState(30);
  const [shown, setShown] = useState(PAGE);

  const { department, position } = useOrgData(["department", "position"]);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError("");
    try {
      setEmployees(extractList(await apiRequest("/employees", {}, signal)));
    } catch (err) {
      if (err?.name !== "AbortError") setError(getErrorMessage(err, "Unable to load employees."));
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  const counts = useMemo(() => countByStatus(employees), [employees]);
  const birthdays = useMemo(() => upcomingDates(employees, "ee_birth_date", windowDays), [employees, windowDays]);
  const anniversaries = useMemo(() => upcomingDates(employees, hireDate, windowDays), [employees, windowDays]);

  const statusRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return employees
      .filter((e) => hasStatus(e, status))
      .filter((e) => !q || `${getFullName(e, "")} ${e.ee_id_number ?? ""}`.toLowerCase().includes(q))
      .sort((a, b) => getFullName(a, "").localeCompare(getFullName(b, "")));
  }, [employees, status, search]);

  const deptName = (e) => department.map.get(String(e.ee_department_reference)) || "—";
  const posName = (e) => position.map.get(String(e.ee_position_reference)) || "—";

  const pickStatus = (value) => { setStatus(value); setSearch(""); setShown(PAGE); };

  return (
    <div className="space-y-5">
      {/* header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Dashboard</h1>
          <p className="text-sm text-slate-500">
            {new Date().toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
        <button
          type="button"
          onClick={() => load()}
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-xl border border-navy-200 bg-white px-3 py-2 text-xs font-semibold text-navy-700 shadow-sm transition hover:bg-navy-50 disabled:opacity-60"
        >
          <i className={`bi bi-arrow-clockwise ${loading ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>

      {error && (
        <div role="alert" className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          <span>{error}</span>
          <button type="button" onClick={() => load()} className="font-semibold underline">Try again</button>
        </div>
      )}

      {/* counts */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8">
        <div className="relative col-span-2 overflow-hidden rounded-2xl bg-navy-800 p-4 text-white shadow-sm sm:col-span-3 lg:col-span-4 xl:col-span-1">
          <span className="absolute inset-x-0 top-0 h-1 bg-gold-500" />
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-gold-200">Total</span>
            <i className="bi bi-people text-lg text-gold-400" />
          </div>
          <p className="mt-2 text-3xl font-extrabold tabular-nums">
            {loading ? <span className="inline-block h-8 w-12 animate-pulse rounded bg-white/20" /> : employees.length}
          </p>
        </div>
        {STATUS_CARDS.map((s) => (
          <StatCard
            key={s.value}
            label={s.value}
            icon={s.icon}
            count={counts[s.value]}
            loading={loading}
            active={status === s.value}
            onClick={() => pickStatus(s.value)}
          />
        ))}
      </div>

      {/* employees of the chosen status */}
      <Panel
        title={`${status} employees (${statusRows.length})`}
        icon="bi-list-ul"
        right={
          <input
            type="search"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setShown(PAGE); }}
            placeholder="Search name or ID…"
            aria-label={`Search ${status} employees`}
            className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none transition focus:border-gold-500 focus:bg-white focus:ring-4 focus:ring-gold-200/60 sm:w-64"
          />
        }
      >
        {loading ? (
          <p className="px-5 py-10 text-center text-sm text-slate-400">Loading employees…</p>
        ) : statusRows.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-slate-400">No {status.toLowerCase()} employees found.</p>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-navy-50 text-[11px] uppercase tracking-wider text-navy-700">
                  <tr>
                    <th className="px-4 py-2.5 font-bold sm:px-5">Employee</th>
                    <th className="px-4 py-2.5 font-bold">ID No.</th>
                    <th className="hidden px-4 py-2.5 font-bold md:table-cell">Department</th>
                    <th className="hidden px-4 py-2.5 font-bold lg:table-cell">Position</th>
                    <th className="hidden px-4 py-2.5 font-bold sm:table-cell">Date hired</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {statusRows.slice(0, shown).map((e, i) => (
                    <tr key={`${e.ee_id_number}-${i}`} className="hover:bg-gold-50/60">
                      <td className="px-4 py-2.5 sm:px-5">
                        <div className="flex items-center gap-3">
                          <Avatar emp={e} />
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-navy-900">{getFullName(e)}</p>
                            <p className="truncate text-xs text-slate-500 md:hidden">{deptName(e)}</p>
                          </div>
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-4 py-2.5 text-slate-600">{e.ee_id_number || "—"}</td>
                      <td className="hidden px-4 py-2.5 text-slate-600 md:table-cell">{deptName(e)}</td>
                      <td className="hidden px-4 py-2.5 text-slate-600 lg:table-cell">{posName(e)}</td>
                      <td className="hidden whitespace-nowrap px-4 py-2.5 text-slate-600 sm:table-cell">{formatDate(hireDate(e))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {statusRows.length > shown && (
              <div className="border-t border-slate-100 p-3 text-center">
                <button type="button" onClick={() => setShown((n) => n + PAGE)} className="text-sm font-semibold text-navy-700 hover:text-gold-700">
                  Show more ({statusRows.length - shown} remaining)
                </button>
              </div>
            )}
          </>
        )}
      </Panel>

      {/* birthdays + anniversaries */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-base font-extrabold text-navy-900">Coming up</h2>
        <div role="group" aria-label="Time window" className="inline-flex rounded-xl border border-slate-200 bg-white p-1 shadow-sm">
          {UPCOMING_WINDOWS.map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setWindowDays(d)}
              aria-pressed={windowDays === d}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${windowDays === d ? "bg-navy-700 text-white" : "text-slate-600 hover:bg-navy-50"}`}
            >
              {d} days
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel title={`Birthdays (${birthdays.length})`} icon="bi-cake2">
          <UpcomingList
            rows={loading ? [] : birthdays}
            empty={loading ? "Loading…" : `No birthdays in the next ${windowDays} days.`}
            tone="gold"
            icon="bi-cake2"
            sub={(e) => `${deptName(e)} · ${posName(e)}`}
            badge={(days) => dayLabel(days)}
          />
        </Panel>
        <Panel title={`Work anniversaries (${anniversaries.length})`} icon="bi-award">
          <UpcomingList
            rows={loading ? [] : anniversaries}
            empty={loading ? "Loading…" : `No work anniversaries in the next ${windowDays} days.`}
            tone="navy"
            icon="bi-award"
            sub={(e, years) => `${years} year${years === 1 ? "" : "s"} of service · ${deptName(e)}`}
            badge={(days) => dayLabel(days)}
          />
        </Panel>
      </div>
    </div>
  );
}

// ---------- entry (default export keeps the old name so AdminIndex needs no change) ----------
export default function DashboardLayout() {
  // UI hint only. The server must still refuse /employees to people without access.
  const [canView] = useState(() => hasRoleAccess(getStoredUser(), "employees"));

  if (!canView) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <i className="bi bi-shield-lock text-3xl text-gold-600" />
        <h1 className="mt-3 text-lg font-extrabold text-navy-900">Welcome</h1>
        <p className="mt-1 text-sm text-slate-500">Employee statistics are available to accounts with Employees access.</p>
      </div>
    );
  }
  return <EmployeeDashboard />;
}
